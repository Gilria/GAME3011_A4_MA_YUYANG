using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line : MonoBehaviour
{
    public enum LineType
    {
        EMPTY,
        YELLOW,
        RED,
        GREEN,
        BLUE,
        PURPLE

    }

    public LineType linetype;

    public Material[] materials;
    private void Update()
    {
        ChangeSprite();
    }

    void ChangeSprite()
    {
        GetComponent<SpriteRenderer>().material = materials[(int)linetype];
    }



}
