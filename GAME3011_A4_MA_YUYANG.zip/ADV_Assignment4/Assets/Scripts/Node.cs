using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node : MonoBehaviour
{


    private GameManager gameManager;
    public GameObject linePrefab;

    

    public bool lineDirection = false;


    public int x;
    public int y;
    public enum NodeType
    {
        EMPTY,
        YELLOW,
        RED,
        GREEN,
        BLUE,
        PURPLE,

        YELLOWLINE,
        REDLINE,
        GREENLINE,
        BLUELINE,
        PURPLELINE


    }
    //[System.Serializable]
    //public struct NodeSprite
    //{
    //    public NodeType color;
    //    public Material material;
    //}

    public NodeType nodetype;

    public Material[] materials;

    private void Start()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
    }

    private void Update()
    {
        ChangeSprite();
        //Debug.Log(gameManager.mousePosition);
        //Debug.Log(clickTrigger);
    }

    void ChangeSprite()
    {
        GetComponent<SpriteRenderer>().material = materials[(int)nodetype];
    }

    private void OnMouseDown()
    {

        
        //Debug.Log(this.nodetype);
        if (this.nodetype != NodeType.EMPTY)
        {
            gameManager.nearNode1 = this;
            gameManager.clickTrigger = true;
            gameManager.isConnected = false;


            GameObject[] destroyLines = GameObject.FindGameObjectsWithTag("Line");


            foreach (GameObject destroyLine in destroyLines)
            {
                if ((int)destroyLine.GetComponent<Line>().linetype == (int)this.nodetype)
                {

                    Destroy(destroyLine);


                }
            }

            foreach (Node destroyNode in gameManager.nodes)
            {
                if ((int)destroyNode.GetComponent<Node>().nodetype == (int)(gameManager.nearNode1.nodetype + 5))
                {
                    destroyNode.GetComponent<Node>().nodetype = NodeType.EMPTY;
                }
            }

        }
        //gameManager.originalMousePosition = gameManager.mousePosition;

        //gameManager.createTrigger = true;

        

        



    }

    private void OnMouseEnter()
    {
        //Debug.Log("Enter");
        if (gameManager.clickTrigger)
        {
            if (gameManager.lastNode && gameManager.lastNode.nodetype != NodeType.EMPTY)
            {
                if (Vector2.Distance(gameManager.lastNode.transform.position,this.transform.position) > 1)
                {
                    gameManager.clickTrigger = false;
                    gameManager.isConnected = false;
                    return;
                }
                Debug.Log(gameManager.lastNode.nodetype);
                if (this.nodetype == NodeType.EMPTY)
                {
                    gameManager.CreateLine(this);
                    //Debug.Log("CreateLine");
                }
                else if (this.nodetype == gameManager.nearNode1.nodetype)
                {
                    gameManager.CreateLine(this);
                    this.nodetype =((this.nodetype) - 5);
                    gameManager.clickTrigger = false;
                    gameManager.isConnected = true;
                }
                else 
                {
                    gameManager.clickTrigger = false;

                }
                
            }
        }
    }
    private void OnMouseExit()
    {
        //Debug.Log("Exit");
        if (gameManager.clickTrigger)
        {
            
            
            gameManager.lastNode = this;
        }
        
        
        
        
        
        
        //if (clickTrigger == true)
        //{
        //    float xValue = Input.GetAxis("Mouse X");
        //    float yValue = Input.GetAxis("Mouse Y");
            
        //    if (Mathf.Abs(xValue) >= Mathf.Abs(yValue)) // drag on x axis
        //    {

        //        Debug.Log("CreatenearNode2");
        //        lineDirection = false;
        //        if (xValue < 0 && gameManager.nearNodes.nearNode1.x >=0)
        //        {
        //            //GameObject line = Instantiate(linePrefab, new Vector2(Mathf.Floor(gameManager.mousePosition.x) + 0.3f, Mathf.Floor(gameManager.mousePosition.y)), Quaternion.identity); //left
        //            //line.transform.Rotate(0, 0, 90);

                    
        //            gameManager.nearNodes.nearNode2 = gameManager.nodes[gameManager.nearNodes.nearNode1.x - 1, gameManager.nearNodes.nearNode1.y];
        //            //gameManager.nearNodes.nearNode1 = gameManager.nearNodes.nearNode2;


        //        }
        //        else if (xValue > 0 && gameManager.nearNodes.nearNode1.x <= gameManager.xColumn)
        //        {

                    
        //            gameManager.nearNodes.nearNode2 = gameManager.nodes[gameManager.nearNodes.nearNode1.x + 1, gameManager.nearNodes.nearNode1.y];
        //            //gameManager.nearNodes.nearNode1 = gameManager.nearNodes.nearNode2;
        //            //GameObject line = Instantiate(linePrefab, new Vector2(Mathf.Floor(gameManager.mousePosition.x) - 0.3f, Mathf.Floor(gameManager.mousePosition.y)), Quaternion.identity); //right
        //            //line.transform.Rotate(0, 0, 90);
        //            //this.nodetype = NodeType.LINE;
        //        }
        //    }
        //    else if (Mathf.Abs(xValue) < Mathf.Abs(yValue)) // drag on y axis
        //    {
        //        //Debug.Log("CreatenearNode2");
        //        lineDirection = true;
        //        if (yValue < 0 && gameManager.nearNodes.nearNode1.y >= 0)
        //        {
                    
        //            gameManager.nearNodes.nearNode2 = gameManager.nodes[gameManager.nearNodes.nearNode1.x, gameManager.nearNodes.nearNode1.y -1];
        //            //gameManager.nearNodes.nearNode1 = gameManager.nearNodes.nearNode2;
        //            //GameObject line = Instantiate(linePrefab, new Vector2(Mathf.Floor(gameManager.mousePosition.x), Mathf.Floor(gameManager.mousePosition.y) + 0.3f), Quaternion.identity); // down
        //            //this.nodetype = NodeType.LINE;

        //        }
        //        else if (yValue > 0 && gameManager.nearNodes.nearNode1.y < gameManager.yRow)
        //        {
                    
        //            gameManager.nearNodes.nearNode2 = gameManager.nodes[gameManager.nearNodes.nearNode1.x, gameManager.nearNodes.nearNode1.y + 1];
        //            //gameManager.nearNodes.nearNode1 = gameManager.nearNodes.nearNode2;
        //            //GameObject line = Instantiate(linePrefab, new Vector2(Mathf.Floor(gameManager.mousePosition.x), Mathf.Floor(gameManager.mousePosition.y) - 0.3f), Quaternion.identity); // up
        //            //this.nodetype = NodeType.LINE;

        //        }
        //    }

        //}
    }

    private void OnMouseUp()
    {
        gameManager.clickTrigger = false;

        //Debug.Log("Destroy");
        //Debug.Log(this.nodetype);

        if (gameManager.isConnected == false)
        {
           
            //Debug.Log("aaaaaaa");
            //Debug.Log("cccccccc");
            GameObject[] destroyLines = GameObject.FindGameObjectsWithTag("Line");

            if (gameManager.nearNode1)
            {
                foreach (GameObject destroyLine in destroyLines)
                {
                    if ((int)destroyLine.GetComponent<Line>().linetype == (int)(gameManager.nearNode1.nodetype))
                    {


                        Destroy(destroyLine);


                    }
                }

                foreach (Node destroyNode in gameManager.nodes)
                {
                    if (gameManager.nearNode1 != null)
                    {
                        if ((int)destroyNode.GetComponent<Node>().nodetype == (int)(gameManager.nearNode1.nodetype + 5))
                        {
                            destroyNode.GetComponent<Node>().nodetype = NodeType.EMPTY;
                        }
                    }

                }
            }
            
        }
        
        
        
        gameManager.nearNode1 = null;
        gameManager.lastNode = null;




        //gameManager.endMousePosition = gameManager.mousePosition;
        //gameManager.createTrigger = false;

    }


    

}
