using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject gridPrefab;
    public GameObject nodePrefab;
    public GameObject linePrefab;
    public GameObject canvas;
    public GameObject inGame;


    public GameObject easy;
    public GameObject normal;
    public GameObject hard;
    public GameObject mainMenu;
    public GameObject quit;
    public GameObject finished;
    public GameObject lose;
    public GameObject skill1;
    public GameObject skill2;
    public GameObject skill3;

    public Text timer1;

    public Vector2 mousePosition;
    public Vector2 originalMousePosition;
    public Vector2 endMousePosition;


    public bool isConnected = false;
    public bool clickTrigger = false;

    public Node[,] nodes;
    public Transform nodeContainer;


    public Node nearNode1;
    
   
    public Node lastNode;

    public float timer;



    public int xColumn = 6;
    public int yRow = 6;
    public int nodeNumber = 0;


    private int[] map = { 0, 0, 0, 0, 0, 1, 
                          0, 0, 0, 0, 2, 3,
                          0, 0, 0, 0, 0, 0,
                          1, 2, 0, 0, 0, 0, 
                          0, 0, 0, 4, 5, 0,
                          3, 5, 0, 0, 0, 4};




    private int[] map2 = { 0, 0, 0, 1, 2, 0,
                          0, 3, 0, 0, 4, 0,
                          0, 0, 1, 0, 0, 0,
                          3, 0, 0, 0, 0, 2,
                          0, 0, 0, 0, 0, 5,
                          4, 5, 0, 0, 0, 0};


    private int[] map1 = { 1, 2, 1, 3, 4, 0,
                          0, 0, 0, 0, 5, 0,
                          0, 0, 0, 0, 0, 0,
                          0, 2, 0, 0, 0, 0,
                          0, 0, 0, 0, 0, 4,
                          3, 0, 0, 0, 0, 5};


    private int[][] maps = new int[3][];
    
    


    private List<GameObject> createPoint = new List<GameObject>();
    void Start()
    {
        maps = new int[][]{map,map1,map2};
        
        for (int y = yRow -1; y >= 0; y--)
        {
            for (int x = 0;  x <= xColumn -1; x++)
            {
                GameObject grid = Instantiate(gridPrefab, new Vector2(x,y), Quaternion.identity);
                grid.transform.position = new Vector2(grid.transform.position.x - 3, grid.transform.position.y - 3);
            }

        }

        nodes = new Node[xColumn, yRow];

        for (int y = yRow -1; y >= 0; y--)
        {
            for (int x = 0; x <= xColumn -1; x++)
            {
                GameObject go = Instantiate(nodePrefab);
                nodes[x, y] = go.GetComponent<Node>();
                nodes[x, y].x = x;
                nodes[x, y].y = y;
                go.transform.position = new Vector2(nodes[x, y].x -3, nodes[x, y].y -3);
                createPoint.Add(go);
            }

        }


        for (int i = 0; i < createPoint.Count; i++)
        {
            createPoint[i].GetComponent<Node>().nodetype = (Node.NodeType)map[i];
        }

        LoadMap(2);



    }


    public void LoadMap(int level)
    {
        for (int i = 0; i < createPoint.Count; i++)
        {
            createPoint[i].GetComponent<Node>().nodetype = (Node.NodeType)maps[level][i];
        }
        inGame.SetActive(true);
        timer = 20 + (level + 1) * 5; 
    }

    public void ChangeMap(int change)
    {
        if (change == 0)
        {
            mainMenu.SetActive(false);
            quit.SetActive(false);


            easy.SetActive(true);
            normal.SetActive(true);
            hard.SetActive(true);
        }

        else if (change == 1)
        {
            mainMenu.SetActive(false);
            quit.SetActive(false);


            easy.SetActive(false);
            normal.SetActive(false);
            hard.SetActive(false);
            finished.SetActive(true);
        }
    }

    public void Skill1(int skill)
    {
        if (skill == 0)
        {
            timer += 5;
        }
        if (skill == 1)
        {
            timer += 8;
        }
        if (skill == 2)
        {
            timer += 10;
        }
    }

   

    
    void Update()
    {
        timer -= 1 * Time.deltaTime;
        timer1.text = timer.ToString();
        if (timer <=0)
        {
            timer = 0;
            mainMenu.SetActive(false);
            quit.SetActive(false);


            easy.SetActive(false);
            normal.SetActive(false);
            hard.SetActive(false);
            finished.SetActive(false);
            skill1.SetActive(false);
            skill2.SetActive(false);
            skill3.SetActive(false);
            lose.SetActive(true);
            

        }
        
        foreach (Node node in nodes)
        {
            if (node.nodetype != Node.NodeType.EMPTY)
            {
                
                nodeNumber++;
            }

        }
        if (nodeNumber == 36 && isConnected)
        {
            canvas.SetActive(true);
            mainMenu.SetActive(true);
            quit.SetActive(true);


            easy.SetActive(false);
            normal.SetActive(false);
            hard.SetActive(false);

            GameObject[] destroyLines = GameObject.FindGameObjectsWithTag("Line");
            foreach (GameObject destroyline in destroyLines)
            {
                Destroy(destroyline);
            }

        }        
        else
        {
            nodeNumber = 0;
        }
        
        MouseFollow();
      
    }


   

    public void CreateLine(Node node)
    {
        GameObject line = Instantiate(linePrefab, node.transform.position, Quaternion.identity);
        node.nodetype = (int)lastNode.nodetype > 5 ? lastNode.nodetype : lastNode.nodetype + 5;

       

        if (node.transform.position.x - lastNode.transform.position.x == 0)
        {
            line.transform.position = new Vector2(node.transform.position.x, (node.transform.position.y + lastNode.transform.position.y)/2);
            
        }
        else
        {
            line.transform.position = new Vector2((node.transform.position.x + lastNode.transform.position.x)/2, node.transform.position.y);
            line.transform.Rotate(0, 0, 90);
        }
        
        
        if ((int)node.nodetype > 5)
        {

           
            line.GetComponent<Line>().linetype = (Line.LineType)((int)(node.nodetype) - 5);
        }

        else
        {
            
            line.GetComponent<Line>().linetype = (Line.LineType)((int)(node.nodetype));
        }
        




    }

    void MouseFollow()
    {

        mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

    }


    














    

}
